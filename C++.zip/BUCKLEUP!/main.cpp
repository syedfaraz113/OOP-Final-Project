#include "Indrive.h"

int main() {
    Indrive app;
    app.menu();
    return 0;
}